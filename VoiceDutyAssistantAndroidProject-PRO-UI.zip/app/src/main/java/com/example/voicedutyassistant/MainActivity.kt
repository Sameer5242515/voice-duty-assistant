package com.example.voicedutyassistant

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.View
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ScrollView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.Calendar
import java.text.SimpleDateFormat

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var dutyInput: EditText
    private lateinit var status: TextView
    private lateinit var rootLayout: LinearLayout
    private lateinit var themeButton: Button
    private lateinit var dateButton: Button
    private lateinit var startTimeButton: Button
    private lateinit var endTimeButton: Button
    private lateinit var wakeCodeInput: EditText
    private lateinit var wakeWordsInput: EditText
    private lateinit var backgroundListeningCheck: CheckBox
    private lateinit var settingsPanel: LinearLayout
    private var selectedDate: String = ""
    private var selectedStartTime: String = "08:00"
    private var selectedEndTime: String = "16:00"
    private var darkMode = false
    private lateinit var tts: TextToSpeech
    private val requestAudio = 301
    private val requestSpeech = 302

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val prefs = getSharedPreferences("duty", MODE_PRIVATE)
        darkMode = prefs.getBoolean("dark_mode", false)
        val today = Calendar.getInstance()
        selectedDate = prefs.getString("duty_date", "")?.takeIf { it.isNotBlank() }
            ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(today.time)
        selectedStartTime = prefs.getString("start_time", "08:00") ?: "08:00"
        selectedEndTime = prefs.getString("end_time", "16:00") ?: "16:00"

        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rootLayout = page
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 28)
        }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = TextView(this).apply {
            text = "Voice Duty Assistant"
            textSize = 24f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 8, 8)
        }
        header.addView(heading, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val overflow = Button(this).apply {
            text = "⋮"
            textSize = 26f
            contentDescription = "Open settings"
            minWidth = 52
            setPadding(4, 0, 4, 0)
            setOnClickListener { toggleSettings() }
        }
        header.addView(overflow, LinearLayout.LayoutParams(56, 52))
        content.addView(header, matchWidth())

        content.addView(TextView(this).apply {
            text = "Your personal shift companion"
            textSize = 15f
            setPadding(0, 0, 0, 18)
        }, matchWidth())

        content.addView(TextView(this).apply {
            text = "YOUR DUTY"
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        }, matchWidth())
        dateButton = Button(this).apply {
            text = "📅  Date   $selectedDate"
            setOnClickListener { chooseDate() }
        }
        content.addView(dateButton, matchWidth())
        startTimeButton = Button(this).apply {
            text = "◷  Start time   $selectedStartTime"
            setOnClickListener { chooseTime(true) }
        }
        content.addView(startTimeButton, matchWidth())
        endTimeButton = Button(this).apply {
            text = "◷  End time   $selectedEndTime"
            setOnClickListener { chooseTime(false) }
        }
        content.addView(endTimeButton, matchWidth())
        dutyInput = EditText(this).apply {
            hint = "Optional note (e.g. morning shift)"
            setText(prefs.getString("schedule_note", ""))
            textSize = 16f
            setPadding(14, 12, 14, 12)
        }
        content.addView(dutyInput, matchWidth())
        content.addView(Button(this).apply {
            text = "Save duty schedule"
            setOnClickListener {
                val note = dutyInput.text.toString().trim()
                val value = "Date $selectedDate, from $selectedStartTime to $selectedEndTime" +
                    if (note.isNotBlank()) ", note: $note" else ""
                prefs.edit().putString("schedule", value).putString("duty_date", selectedDate)
                    .putString("start_time", selectedStartTime).putString("end_time", selectedEndTime)
                    .putString("schedule_note", note).apply()
                respond("Your duty schedule has been saved: $value")
            }
        }, matchWidth())
        content.addView(Button(this).apply {
            text = "🎙  Ask about my duty"
            setOnClickListener { startVoiceInput() }
        }, matchWidth())

        status = TextView(this).apply {
            text = "Save your schedule, then ask me about your duty."
            textSize = 15f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 18, 14, 18)
        }
        content.addView(status, matchWidth())

        // Settings drawer opened by the three-dot menu on the top-right.
        settingsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 12)
            visibility = View.GONE
            alpha = 0f
            elevation = 8f
        }
        settingsPanel.addView(TextView(this).apply {
            text = "SETTINGS"
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, matchWidth())
        themeButton = Button(this).apply {
            setOnClickListener {
                darkMode = !darkMode
                prefs.edit().putBoolean("dark_mode", darkMode).apply()
                applyTheme()
            }
        }
        settingsPanel.addView(themeButton, matchWidth())
        settingsPanel.addView(TextView(this).apply {
            text = "Background wake phrase"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 10, 0, 4)
        }, matchWidth())
        settingsPanel.addView(TextView(this).apply {
            text = "Set a private code and wake words. Example: ‘blue seven, hello duty’."
            textSize = 14f
        }, matchWidth())
        wakeCodeInput = EditText(this).apply {
            hint = "Background code"
            setText(prefs.getString("wake_code", "blue seven"))
            textSize = 16f
        }
        settingsPanel.addView(wakeCodeInput, matchWidth())
        wakeWordsInput = EditText(this).apply {
            hint = "Wake words"
            setText(prefs.getString("wake_words", "hello duty"))
            textSize = 16f
        }
        settingsPanel.addView(wakeWordsInput, matchWidth())
        settingsPanel.addView(Button(this).apply {
            text = "Save wake phrase"
            setOnClickListener {
                val code = wakeCodeInput.text.toString().trim()
                val words = wakeWordsInput.text.toString().trim()
                if (code.isBlank() || words.isBlank()) {
                    Toast.makeText(this@MainActivity, "Enter both a code and wake words.", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putString("wake_code", code).putString("wake_words", words).apply()
                    Toast.makeText(this@MainActivity, "Wake phrase saved.", Toast.LENGTH_SHORT).show()
                }
            }
        }, matchWidth())
        backgroundListeningCheck = CheckBox(this).apply {
            text = "✓  Start background wake listening"
            textSize = 16f
            isChecked = false
            setOnCheckedChangeListener { _, checked ->
                if (checked) startBackgroundListening(prefs)
                else {
                    stopService(Intent(this@MainActivity, WakeWordService::class.java))
                    prefs.edit().putBoolean("background_listening", false).apply()
                    status.text = "Background wake listening is off."
                }
            }
        }
        settingsPanel.addView(backgroundListeningCheck, matchWidth())
        settingsPanel.addView(TextView(this).apply {
            text = "Listening uses Android speech recognition. Some phones/services may play a system tone when listening restarts; fully silent Siri-style wake detection requires a dedicated on-device wake-word engine."
            textSize = 12f
            setPadding(0, 4, 0, 8)
        }, matchWidth())
        content.addView(settingsPanel, 1, matchWidth())
        setContentView(page)
        applyTheme()
    }

    private fun toggleSettings() {
        if (settingsPanel.visibility == View.VISIBLE) {
            settingsPanel.animate().alpha(0f).translationY(-10f).setDuration(180).withEndAction {
                settingsPanel.visibility = View.GONE
                settingsPanel.translationY = 0f
            }.start()
        } else {
            settingsPanel.visibility = View.VISIBLE
            settingsPanel.alpha = 0f
            settingsPanel.translationY = -10f
            settingsPanel.animate().alpha(1f).translationY(0f).setDuration(220).start()
        }
    }

    private fun startBackgroundListening(prefs: android.content.SharedPreferences) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            backgroundListeningCheck.isChecked = false
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val code = wakeCodeInput.text.toString().trim()
        val words = wakeWordsInput.text.toString().trim()
        if (code.isBlank() || words.isBlank()) {
            backgroundListeningCheck.isChecked = false
            Toast.makeText(this, "Enter both a code and wake words first.", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putString("wake_code", code).putString("wake_words", words)
            .putBoolean("background_listening", true).apply()
        val serviceIntent = Intent(this, WakeWordService::class.java).apply { action = WakeWordService.ACTION_START }
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        status.text = "Background wake listening is on. Say your code and wake words together."
    }


    private fun chooseDate() {
        val parts = selectedDate.split("-")
        val year = parts.getOrNull(0)?.toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
        val month = (parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1
        val day = parts.getOrNull(2)?.toIntOrNull() ?: 1
        DatePickerDialog(this, { _, pickedYear, pickedMonth, pickedDay ->
            selectedDate = String.format(Locale.US, "%04d-%02d-%02d", pickedYear, pickedMonth + 1, pickedDay)
            dateButton.text = "📅 Date: $selectedDate"
        }, year, month.coerceIn(0, 11), day).show()
    }

    private fun chooseTime(isStart: Boolean) {
        val current = if (isStart) selectedStartTime else selectedEndTime
        val parts = current.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: if (isStart) 8 else 16
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        TimePickerDialog(this, { _, pickedHour, pickedMinute ->
            val value = String.format(Locale.US, "%02d:%02d", pickedHour, pickedMinute)
            if (isStart) {
                selectedStartTime = value
                startTimeButton.text = "🕒 Start time: $selectedStartTime"
            } else {
                selectedEndTime = value
                endTimeButton.text = "🕒 End time: $selectedEndTime"
            }
        }, hour.coerceIn(0, 23), minute.coerceIn(0, 59), true).show()
    }

    private fun applyTheme() {
        val background = if (darkMode) Color.rgb(24, 27, 32) else Color.rgb(248, 249, 252)
        val foreground = if (darkMode) Color.rgb(238, 240, 244) else Color.rgb(30, 34, 40)
        val accent = if (darkMode) Color.rgb(86, 156, 245) else Color.rgb(35, 105, 210)
        val fieldBackground = if (darkMode) Color.rgb(42, 46, 54) else Color.WHITE
        rootLayout.setBackgroundColor(background)
        settingsPanel.setBackgroundColor(fieldBackground)
        themeButton.text = if (darkMode) "☀️ Switch to Light Mode" else "🌙 Switch to Dark Mode"
        fun paint(view: View) {
            when (view) {
                is CheckBox -> { view.setTextColor(foreground); view.buttonTintList = ColorStateList.valueOf(accent) }
                is Button -> {
                    view.setTextColor(Color.WHITE)
                    view.backgroundTintList = ColorStateList.valueOf(accent)
                }
                is EditText -> {
                    view.setTextColor(foreground)
                    view.setHintTextColor(if (darkMode) Color.LTGRAY else Color.GRAY)
                    view.backgroundTintList = ColorStateList.valueOf(if (darkMode) accent else Color.GRAY)
                    view.setBackgroundColor(fieldBackground)
                }
                is TextView -> view.setTextColor(foreground)
            }
            if (view is android.view.ViewGroup) {
                for (i in 0 until view.childCount) paint(view.getChildAt(i))
            }
        }
        paint(rootLayout)
        dutyInput.setTextColor(foreground)
        dutyInput.setHintTextColor(if (darkMode) Color.LTGRAY else Color.GRAY)
        dutyInput.setBackgroundTintList(ColorStateList.valueOf(accent))
    }

    private fun matchWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = 12
        }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.US
    }

    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("Voice recognition is not available on this phone. Please install or enable Google's speech recognition service.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Ask about your duty schedule")
        }
        try {
            startActivityForResult(intent, requestSpeech)
        } catch (_: Exception) {
            respond("I could not start voice recognition. Please try again.")
        }
    }

    @Deprecated("Legacy activity result API remains widely supported")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val question = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            val duty = getSharedPreferences("duty", MODE_PRIVATE).getString("schedule", "").orEmpty()
            val q = question.lowercase(Locale.ROOT)
            val answer = when {
                duty.isBlank() -> "You have not saved your duty schedule yet."
                listOf("duty", "work", "schedule", "time", "working", "shift").any { q.contains(it) } ->
                    "Your saved duty schedule is $duty"
                else -> "I heard $question. Please ask me about your duty schedule."
            }
            respond(answer)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            if (::backgroundListeningCheck.isInitialized && backgroundListeningCheck.isChecked) {
                startBackgroundListening(getSharedPreferences("duty", MODE_PRIVATE))
            } else startVoiceInput()
        } else if (requestCode == requestAudio) {
            if (::backgroundListeningCheck.isInitialized) backgroundListeningCheck.isChecked = false
            Toast.makeText(this, "Microphone permission is needed for voice features.", Toast.LENGTH_LONG).show()
        }
    }

    private fun respond(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "duty_reply")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
