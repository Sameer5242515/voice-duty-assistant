package com.example.voicedutyassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var dutyInput: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val requestAudio = 301
    private val requestSpeech = 302

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val prefs = getSharedPreferences("duty", MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "🎙️ Voice Duty Assistant"
            textSize = 25f
            gravity = Gravity.CENTER
        }, matchWidth())
        layout.addView(TextView(this).apply {
            text = "Save your duty schedule and ask about it by voice."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 20)
        }, matchWidth())

        dutyInput = EditText(this).apply {
            hint = "Example: Monday 08:00 to 16:00"
            setText(prefs.getString("schedule", ""))
            textSize = 18f
        }
        layout.addView(dutyInput, matchWidth())

        layout.addView(Button(this).apply {
            text = "Save Duty Time"
            setOnClickListener {
                val value = dutyInput.text.toString().trim()
                if (value.isEmpty()) {
                    respond("Please enter your duty schedule first.")
                } else {
                    prefs.edit().putString("schedule", value).apply()
                    respond("Your duty schedule has been saved: $value")
                }
            }
        }, matchWidth())

        layout.addView(Button(this).apply {
            text = "🎤 Ask by Voice"
            setOnClickListener { startVoiceInput() }
        }, matchWidth())

        status = TextView(this).apply {
            text = "Your saved duty schedule will appear here."
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        layout.addView(status, matchWidth())
        setContentView(layout)
    }

    private fun matchWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = 12
        }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.US
    }

    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("Voice recognition is not available on this phone. Please install or enable Google's speech recognition service.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Ask about your duty schedule")
        }
        try {
            startActivityForResult(intent, requestSpeech)
        } catch (_: Exception) {
            respond("I could not start voice recognition. Please try again.")
        }
    }

    @Deprecated("Legacy activity result API remains widely supported")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val question = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            val duty = getSharedPreferences("duty", MODE_PRIVATE).getString("schedule", "").orEmpty()
            val q = question.lowercase(Locale.ROOT)
            val answer = when {
                duty.isBlank() -> "You have not saved your duty schedule yet."
                listOf("duty", "work", "schedule", "time", "working", "shift").any { q.contains(it) } ->
                    "Your saved duty schedule is $duty"
                else -> "I heard $question. Please ask me about your duty schedule."
            }
            respond(answer)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startVoiceInput()
        else if (requestCode == requestAudio) Toast.makeText(this, "Microphone permission is needed for voice questions.", Toast.LENGTH_LONG).show()
    }

    private fun respond(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "duty_reply")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
